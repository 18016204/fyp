<?php

session_start();

header("Location: login.php");
?>