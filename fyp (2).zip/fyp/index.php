<html>
<head>


<link href="css/chart.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <div id="container"></div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>

<script src="js/test.js" type="text/javascript"></script>
</html>